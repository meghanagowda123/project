import React,{Component} from 'react';
import { Form, Button } from 'react-bootstrap';
export default class Search extends Component {
    render() {
        return (

            <div className='search-content-box'>
            <div className='job-search-box'>
              <Form className='form-wrapper-job-search'>
                <Form.Group
                  className='search-job-input-item'
                  controlId='formBasicEmail'>
                  <Form.Control
                    className='search-job-input-field'
                    type='text'
                    placeholder='Post or Company or Role'
                    value=''
                  />
                </Form.Group>
                <Form.Group
                  className='search-job-input-item'
                  controlId='formBasicEmail'>
                  <Form.Control
                    className='search-job-input-field'
                    type='text'
                    placeholder='Place'
                  />
                </Form.Group>
                <Button variant='primary' size='lg' active>
                   Search
                </Button>
              </Form>
            </div>
            <div className='more-tag-line'>
             {/* <h4>It only takes a few seconds</h4>
              <h4>post a job, search resumes, and more</h4>*/}
            </div>
          </div>
           
        );
    }
}