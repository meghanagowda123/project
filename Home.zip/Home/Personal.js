import React, {Component} from 'react';
import Button from 'react-bootstrap/Button';
import axios from 'axios';

export default class Personal extends Component{
    constructor(props){
        super(props)
        
        this.state = {
            name : '',
            emailId: '',
            password: '',
            mobno:'',
            address:'',
            workexp:'',
            skills:'',
            uploadres : ''
        }
        this.onChangename = this.onChangename.bind(this)
        this.onChangeemailId = this.onChangeemailId.bind(this)
        this.onChangepassword = this.onChangepassword.bind(this)
        this.onChangemobno = this.onChangemobno.bind(this)
        this.onChangeaddress = this.onChangeaddress.bind(this)
        this.onChangeworkexp = this.onChangeworkexp.bind(this)
        this.onChangeskills = this.onChangeskills.bind(this)
        this.onChangeuploadres = this.onChangeuploadres.bind(this)
        this.submitForm = this.submitForm.bind(this)
    }

    onChangename(e) {
        this.setState({  name: e.target.value})
    }

    onChangeemailId(e) {
        this.setState({emailId  : e.target.value})
    }

    onChangepassword(e) {
        this.setState({ password : e.target.value})
    }

    onChangemobno(e) {
        this.setState({ mobno : e.target.value})
    }

    onChangeaddress(e) {
        this.setState({ address : e.target.value})
    }

    onChangeworkexp(e) {
        this.setState({ workexp : e.target.value})
    }

    onChangeskills(e) {
        this.setState({ skills : e.target.value})
    }

    onChangeuploadres(e) {
        this.setState({ uploadres : e.target.value})
    }
   
    

    submitForm(e){
        e.preventDefault()
        const userObj={ 
            name : this.state.name,
            emailId:this.state.emailId,
            password:this.state.password,
            mobno:this.state.mobno,
            address:this.state.address,
            workexp:this.state.workexp,
            skills:this.state.skills,
            uploadres:this.state.uploadres
         };

         axios.post('http://localhost:8081/personals/post-personal',userObj)
         .then(res => console.log(res.data));
         
         alert(`User successfully created!`)
         this.setState({
            name : '',
            emailId: '',
            password: '',
            mobno:'',
            address:'',
            workexp:'',
            skills:'',
            uploadres : ''

         });
       
        
    }
    render(){
        
        return(
            <div className="form-wrapper">
                <h1>Personal</h1>

                <form onSubmit={this.submitForm}>
                <label htmlFor="name"><b>Name</b></label>
                  <input type="text" placeholder="Enter your full name" name="name" value={this.state.name} onChange={this.onChangename}/>
                  
                  <br/>
                  <label htmlFor="emailId"><b>Email Id</b></label>
                  <input type="text" placeholder="Enter your email id" name="emailId" value={this.state.emailId} onChange={this.onChangeemailId}/>
                  <br/>
                  <label htmlFor="password"><b>Password</b></label> 
            
                  <input type="password" placeholder="Password" name="password" value={this.state.password} onChange={this.onChangepassword}/>
                  <br/>
                  <label htmlFor="mobno"><b>Mobile No</b></label>
                  <input type="text" placeholder="Mobile No" name="mobno" value={this.state.mobno} onChange={this.onChangemobno}/>
                  <br/>
                  <label htmlFor="address"><b>Address</b></label>
                  <input type="text" placeholder="Address Line1" name="address" value={this.state.address} onChange={this.onChangeaddress}/>
                  {/* <input type="text" placeholder="Address Line2" name="address" value={this.state.address} onChange={this.onChangeaddress}/>
                  
                  <input type="text" id="textbox1" placeholder="City" name="address" value={this.state.address} onChange={this.onChangeaddress}/>
                  &nbsp;&nbsp;&nbsp;
                  <input type="text" id="textbox2" placeholder="State" name="address" value={this.state.address} onChange={this.onChangeaddress}/>
                   */}
                  <br/>
                  <br/>
                  <label htmlFor="workexp"><b>Total Work Experience</b></label>
                  <input type="text" placeholder="Year" name="workexp" value={this.state.workexp} onChange={this.onChangeworkexp}/>
                  <input type="text" placeholder="Month" name="workexp" value={this.state.workexp} onChange={this.onChangeworkexp}/>
                  <br/>
                  <label htmlFor="skills"><b>Skills</b></label>
                  <input type="text" placeholder="Skills" name="skills" value={this.state.skills} onChange={this.onChangeskills}/>
                  <br/>
                  <label htmlFor="uploadres"><b>Upload Resume</b></label>
                  <input type="text" placeholder="Upload" name="uploadres" value={this.state.uploadres} onChange={this.onChangeuploadres}/>
                  <br/>
                  <br/>
                  <Button variant="danger" size="lg" block="block" type="submit">
                    Register
                    </Button>
                </form> 
            </div>
        );
    }
}
