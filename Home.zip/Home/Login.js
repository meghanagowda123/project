import React, {Component} from 'react';
import { Button } from 'react-bootstrap';
import { Redirect } from 'react-router-dom';
import JobList from '../Admin/JobList';
import {Row, Col} from 'react-bootstrap';
export default class Login extends Component{
    constructor(props){
        super(props)
        let loggedIn = false
        this.state = {
            userId: '',
            password: '',
            loggedIn
        }
        this.onChange = this.onChange.bind(this)
        this.submitForm = this.submitForm.bind(this)
    }
    onChange(e){
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    submitForm(e){
        e.preventDefault()
        const { userId,password } = this.state

        if(userId === "sneha" && password === "123"){
            this.setState({
                loggedIn: true
            })
        }
    }
    render(){
        if(this.state.loggedIn){
            return <Redirect to="/JobList"/> 
        }
        return(
            <div>
                <div className="row mt-5">
                    <div className="col-md-6 m-auto">
                            <form onSubmit={this.submitForm}>
                                <h4>Login</h4>
                                <div className="form-group">
                                    <input
                                        typeof="text"
                                        id="userId"
                                        required
                                        className="form-control"
                                        placeholder="user Id"
                                        name="userId" value={this.state.userId} onChange={this.onChange}
                                    />
                                </div>
                                <div className="form-group">
                                    <input
                                        type="password"
                                        id="password"
                                        required
                                        className="form-control"
                                        placeholder="Enter Password"
                                        name="password" value={this.state.password} onChange={this.onChange}
                                    />
                                </div>
                                <button typeof="submit" className="btn sm btn-primary " onClick={JobList.js}>Login</button>
                            </form>
                            <p className="lead mt-4">
                               <h6>New User? Register as</h6>
                               <Row>
                                   <Col sm={4}>
                               <h6><a href="/fresherReg">Fresher /</a></h6></Col><Col sm={2}><h6><a href="/experienceReg">Experience</a></h6></Col>
                               </Row>
                            </p>
                    </div>
                </div>
            </div>
        )

    }
}