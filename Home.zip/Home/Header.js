import React, {Component} from 'react';
import Login from './Login';
import {Col} from 'react-bootstrap';
export default class Header extends Component{
    render(){
        return(
            <div className="nav">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                        <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
                        <ul class="navbar-nav">
                            <li class="nav-item active">
                            <a class="nav-link" href="JobList.js">Jobs</a>
                            </li>
                            <li class="nav-item active">
                            <a class="nav-link" href="Companies.js">Companies</a>
                            </li>
                            
                            <li class="nav-item active">
                            <a class="nav-link" href="Logout.js">Logout</a>
                            </li>
                        </ul>
                        </div>
                        </nav>
                    
            </div>
           
        );
    }
}