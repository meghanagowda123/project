import React, { Component } from 'react';
import Header from './Header';
import Login from './Login';
//import Search from './Search';
import Hotjobs from './Hotjobs';
import { Row, Col } from 'react-bootstrap';
import Companies from './Companies';
import Careertips from './Careertips';
export default  class Layout extends Component{
    render(){
        return(
            <div>
                <Header/>
                <Row>
                <Col>
                  
                </Col>
                <Col sm={6}>
                    <Login/>
                </Col>
                </Row>
                <Hotjobs/>
                <Companies/>
                <Careertips/>
            </div>
        );
    }
} 