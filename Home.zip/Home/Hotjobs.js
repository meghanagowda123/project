import React, {Component} from 'react';
import {Row, Col} from 'react-bootstrap';
export default class Hobjobs extends Component{
    render(){
        return(
            <div>
            <h3>Hot Jobs</h3>
            <div className="row">
                <Col sm={4}>
                <div className="card">
                    <h5><b>LAD Software Solutions</b></h5>
                    <h6>VP of marketing B2B</h6>
                    <h6>Experirnce: 8-13years</h6>
                    <h6>Location: Jaipur/ Kochi/ Ernakulam</h6>
                </div>
                </Col>
                <Col sm={4}>
                <div className="card">
                    <h5><b>LAD Software Solutions</b></h5>
                    <h6>Project Manager-IT staffing</h6>
                    <h6>Experirnce: 8-13years</h6>
                    <h6>Location: Jaipur/ Kochi/ Ernakulam</h6>
                </div>
                </Col>
                <Col sm={4}>
                <div className="card">
                    <h5><b>LAD Software Solutions</b></h5>
                    <h6>Inside Sales/ SDR/ </h6>
                    <h6>Experirnce: 8-13years</h6>
                    <h6>Location: Jaipur/ Kochi/ Ernakulam</h6>
                </div>
                </Col>
            </div>
            </div>
        );
    }
}